"""Test suite for SmartAmazon API"""
